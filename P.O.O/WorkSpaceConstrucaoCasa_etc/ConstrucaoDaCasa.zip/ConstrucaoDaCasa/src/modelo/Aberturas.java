package modelo;

public abstract class Aberturas {

}
