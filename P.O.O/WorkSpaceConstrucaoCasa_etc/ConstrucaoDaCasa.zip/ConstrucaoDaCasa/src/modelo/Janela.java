package modelo;

public class Janela {

}
