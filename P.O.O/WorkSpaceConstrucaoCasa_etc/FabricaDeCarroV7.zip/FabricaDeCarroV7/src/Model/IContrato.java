package Model;

public interface IContrato {
	
	public void setCor (String cor);
	public void setModelo (String modelo);
	public String tipo_carro();
}
