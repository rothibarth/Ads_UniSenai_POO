package Model;

public abstract class CarroBase implements IContrato{
	
	protected String modelo;
	
	protected String cor;
	
	public String getModelo() {
		
		return this.modelo;
	}
	
	public void setModelo(String modelo ) {
		
		 this.modelo = modelo; 
	}
	
	public String getCor() {
		
		return this.cor;
	}
	
	public void setCor(String cor ) {
		
		 this.cor = cor; 
	}
}
